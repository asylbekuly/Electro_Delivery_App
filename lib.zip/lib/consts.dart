import 'package:flutter/material.dart';
//color
const korange = Color(0xFFf87b36);
const kblack = Color(0xFF2a2f44);
const kyellow = Color(0xFFf5ba61);
const kpink = Color(0xFFf286bd);
const kbgColor = Color(0xFFf5f5f5);